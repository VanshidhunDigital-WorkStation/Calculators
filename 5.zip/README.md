# Vanshidhun Pro Calculator

A responsive scientific calculator web application built with Python Flask, HTML, CSS and JavaScript.

## Features
- Basic arithmetic: addition, subtraction, multiplication, division and modulo
- Scientific functions: square root, trigonometry, inverse trigonometry, logarithms and factorial
- RAD / DEG angle mode
- Calculation history (local JSON file)
- Memory controls (M+, M-, MR, MC)
- Dark / light theme
- Copy result
- Keyboard support
- JSON API and health endpoint

## Requirements
- Python 3.9 or newer
- pip

## Run locally
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux/Termux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000 in your browser.

## API
- `POST /api/calculate` with JSON `{"expression":"2+2"}`
- `GET /api/history`
- `POST /api/history/clear`
- `GET /api/health`

## Notes
This project is intended for local use and learning. Before public production deployment, add authentication, CSRF protection, per-user history storage, rate limiting, and a production WSGI server. The included JSON history file is shared by all visitors to the same running instance.

## Developer
Vanshidhun Digital

## Version
1.0.0
