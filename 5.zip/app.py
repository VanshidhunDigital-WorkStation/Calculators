from datetime import datetime
import json
import os
from flask import Flask, jsonify, render_template, request
from calculator import safe_calculate
from config import DATA_DIR, HISTORY_FILE, MAX_HISTORY, SECRET_KEY

app = Flask(__name__)
app.config["SECRET_KEY"] = SECRET_KEY
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024

def load_history():
    os.makedirs(DATA_DIR, exist_ok=True)
    if not os.path.exists(HISTORY_FILE):
        return []
    try:
        with open(HISTORY_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except (OSError, json.JSONDecodeError):
        return []

def save_history(history):
    os.makedirs(DATA_DIR, exist_ok=True)
    temp_file = HISTORY_FILE + ".tmp"
    with open(temp_file, "w", encoding="utf-8") as f:
        json.dump(history[:MAX_HISTORY], f, ensure_ascii=False, indent=2)
    os.replace(temp_file, HISTORY_FILE)

@app.get("/")
def home():
    return render_template("index.html")

@app.post("/api/calculate")
def calculate():
    data = request.get_json(silent=True) or {}
    expression = data.get("expression", "")
    try:
        result = safe_calculate(expression)
        history = load_history()
        history.insert(0, {
            "expression": expression,
            "result": str(result),
            "time": datetime.now().astimezone().strftime("%d-%m-%Y %H:%M:%S")
        })
        save_history(history)
        return jsonify(success=True, result=result)
    except (ValueError, TypeError, ArithmeticError) as error:
        return jsonify(success=False, error=str(error)), 400

@app.get("/api/history")
def history():
    return jsonify(load_history())

@app.post("/api/history/clear")
def clear_history():
    save_history([])
    return jsonify(success=True, message="History cleared")

@app.get("/api/health")
def health():
    return jsonify(status="online", application="Vanshidhun Pro Calculator", version="1.0.0")

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
