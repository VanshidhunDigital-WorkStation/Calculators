import ast
import math
import operator

OPERATORS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
    ast.USub: operator.neg,
    ast.UAdd: operator.pos,
}

FUNCTIONS = {
    "sqrt": math.sqrt,
    "sin": math.sin, "cos": math.cos, "tan": math.tan,
    "asin": math.asin, "acos": math.acos, "atan": math.atan,
    "log": math.log10, "ln": math.log,
    "factorial": math.factorial, "abs": abs,
}

CONSTANTS = {"pi": math.pi, "e": math.e}

def safe_calculate(expression: str):
    if not isinstance(expression, str) or not expression.strip():
        raise ValueError("Enter an expression")
    if len(expression) > 300:
        raise ValueError("Expression too long")
    try:
        tree = ast.parse(expression.replace("^", "**"), mode="eval")
        result = evaluate(tree.body)
        if isinstance(result, (int, float)) and not math.isfinite(result):
            raise ValueError("Result is not finite")
        return result
    except ZeroDivisionError:
        raise ValueError("Cannot divide by zero")
    except (SyntaxError, OverflowError, ValueError) as exc:
        raise ValueError(str(exc) or "Invalid expression")

def evaluate(node):
    if isinstance(node, ast.Constant):
        if type(node.value) in (int, float):
            return node.value
        raise ValueError("Invalid number")
    if isinstance(node, ast.Name):
        if node.id in CONSTANTS:
            return CONSTANTS[node.id]
        raise ValueError("Unknown constant")
    if isinstance(node, ast.UnaryOp):
        op = type(node.op)
        if op not in OPERATORS:
            raise ValueError("Invalid operator")
        return OPERATORS[op](evaluate(node.operand))
    if isinstance(node, ast.BinOp):
        op = type(node.op)
        if op not in OPERATORS:
            raise ValueError("Invalid operator")
        left, right = evaluate(node.left), evaluate(node.right)
        if op is ast.Pow and (abs(right) > 1000 or abs(left) > 1e100):
            raise ValueError("Power limit exceeded")
        return OPERATORS[op](left, right)
    if isinstance(node, ast.Call):
        if not isinstance(node.func, ast.Name) or node.func.id not in FUNCTIONS:
            raise ValueError("Unknown function")
        if len(node.args) != 1 or node.keywords:
            raise ValueError("Invalid function arguments")
        name = node.func.id
        value = evaluate(node.args[0])
        if name == "factorial":
            if type(value) is not int or value < 0 or value > 1000:
                raise ValueError("Factorial requires an integer from 0 to 1000")
        return FUNCTIONS[name](value)
    raise ValueError("Invalid expression")
