const expressionDisplay = document.getElementById("expression");
const resultDisplay = document.getElementById("result");
const messageDisplay = document.getElementById("message");
let expression = "";
let memory = 0;
let lastResult = 0;
let angleMode = "RAD";

function updateDisplay() {
  expressionDisplay.textContent = expression || "0";
}
function showMessage(message = "") {
  messageDisplay.textContent = message;
}
function toServerExpression(value) {
  // Convert trig arguments from selected degrees to radians.
  if (angleMode === "DEG") {
    value = value.replace(/\b(sin|cos|tan)\(([^()]*)\)/g, (_, fn, arg) => `${fn}((${arg})*pi/180)`);
    value = value.replace(/\b(asin|acos|atan)\(([^()]*)\)/g, (_, fn, arg) => `(${fn}(${arg})*180/pi)`);
  }
  return value;
}
async function calculate() {
  if (!expression.trim()) return;
  showMessage("");
  try {
    const response = await fetch("/api/calculate", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({expression: toServerExpression(expression)})
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Calculation failed");
    lastResult = Number(data.result);
    resultDisplay.textContent = data.result;
    await loadHistory();
  } catch (error) {
    resultDisplay.textContent = "Error";
    showMessage(error.message);
  }
}
document.querySelectorAll("[data-value]").forEach(button => {
  button.addEventListener("click", () => {
    if (expression.length >= 300) return;
    expression += button.dataset.value;
    updateDisplay(); showMessage("");
  });
});
document.querySelectorAll("[data-action]").forEach(button => {
  button.addEventListener("click", async () => {
    switch (button.dataset.action) {
      case "clear": expression = ""; resultDisplay.textContent = "0"; showMessage(""); updateDisplay(); break;
      case "delete": expression = expression.slice(0,-1); updateDisplay(); break;
      case "calculate": await calculate(); break;
      case "memory-add": memory += lastResult; showMessage("Added to memory"); break;
      case "memory-sub": memory -= lastResult; showMessage("Subtracted from memory"); break;
      case "memory-read": expression += String(memory); updateDisplay(); break;
      case "memory-clear": memory = 0; showMessage("Memory cleared"); break;
    }
  });
});
async function loadHistory() {
  const response = await fetch("/api/history");
  const history = await response.json();
  const list = document.getElementById("historyList");
  list.replaceChildren();
  if (!history.length) {
    const empty = document.createElement("p");
    empty.className = "empty"; empty.textContent = "No calculations yet.";
    list.appendChild(empty); return;
  }
  history.forEach(item => {
    const div = document.createElement("div");
    div.className = "history-item";
    const title = document.createElement("strong");
    title.textContent = `${item.expression} = ${item.result}`;
    const time = document.createElement("small"); time.textContent = item.time;
    div.append(title,time);
    div.addEventListener("click", () => {
      expression = item.expression; updateDisplay();
      resultDisplay.textContent = item.result; showMessage("");
    });
    list.appendChild(div);
  });
}
document.getElementById("clearHistory").addEventListener("click", async () => {
  if (!confirm("Clear all calculation history?")) return;
  await fetch("/api/history/clear", {method:"POST"});
  await loadHistory();
});
document.getElementById("themeBtn").addEventListener("click", () => {
  document.body.classList.toggle("light");
});
document.getElementById("angleBtn").addEventListener("click", event => {
  angleMode = angleMode === "RAD" ? "DEG" : "RAD";
  event.currentTarget.textContent = angleMode;
});
document.getElementById("copyBtn").addEventListener("click", async () => {
  try {
    await navigator.clipboard.writeText(resultDisplay.textContent);
    showMessage("Result copied");
  } catch {
    showMessage("Clipboard access unavailable");
  }
});
document.addEventListener("keydown", event => {
  if (event.target.matches("input,textarea")) return;
  if (/^[0-9+\-*/().%]$/.test(event.key)) {
    if (expression.length < 300) expression += event.key;
    updateDisplay();
  } else if (event.key === "Enter") {
    event.preventDefault(); calculate();
  } else if (event.key === "Backspace") {
    expression = expression.slice(0,-1); updateDisplay();
  } else if (event.key === "Escape") {
    expression = ""; resultDisplay.textContent = "0"; showMessage(""); updateDisplay();
  }
});
loadHistory().catch(() => showMessage("Could not load history"));
